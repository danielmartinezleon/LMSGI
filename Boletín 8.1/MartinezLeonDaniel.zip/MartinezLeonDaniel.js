function redondearElementos(unArray){
    for(let i = 0; i < unArray.length; i++){
        if (!isNaN(unArray[i])){
            let num = Math.round(unArray[i]);
            unArray[i] = num;
        }else{
            unArray[i] = unArray[i].splice(i, 1);
        }
    }

    return unArray;
}

function eliminarExtremos(unArray){
    let min = Math.min(unArray);
    let max = Math.max(unArray);

    unArray.splice(min,1);
    unArray.splice(max,1);

    return unArray;
}

function parsearNotas(str){
    let array = str.split("");
   
    for(let i = 0; i < array.length; i++){
        if(isNaN(array[i]) && array[i] != "."){
            array = array.splice(i, 1);
        }
    }

    return array;
}

function principal(){
    let cadena = "Jurado1:4.56#Jurado2:nulo#Jurado3:9.28#Jurado4:3.34#Jurado5:5.9#Jurado6:7.32"
    let array1 = parsearNotas(cadena);
    let array2 = redondearElementos(array1);
    let array3 = eliminarExtremos(array2);

    alert(array3);
   
}